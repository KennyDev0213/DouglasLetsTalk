package com.example.utility;

public class Location {
    private int locationID;
    private String locationName;
    private String address;
    private int capacity;

    public void chooseLocation(String locationName, String address){
        this.locationName = locationName;
        this.address = address;
    }

    //this class needs to be fleshed out a bit
}
