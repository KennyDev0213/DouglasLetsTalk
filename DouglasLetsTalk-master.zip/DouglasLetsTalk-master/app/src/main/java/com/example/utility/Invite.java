package com.example.utility;

public class Invite {
    private int inviteID;
    private int groupID; //which group the invite is for
    private String description;


    //I think these methods should be used in an invite controller instead
    public void viewInvites(){

    }

    public void sentInvites(){

    }

    public void responseInvites(){

    }
}
